// College logos for the education section 
export const educationLogos = {
  "College of Cape Town": "https://collegeofcapetown.co.za/wp-content/uploads/2021/05/CCT_Logo_1.jpg",
  "Phumelela ALC": "https://media.licdn.com/dms/image/C4D0BAQGLwv_2phAkAw/company-logo_200_200/0/1657801589845?e=2147483647&v=beta&t=dqWOZNRXnBn_vdUdCQ3FRbx3MUCmCMeHiZsP8bBz-28",
  "Fezeka Senior Secondary School": "https://static.wixstatic.com/media/2a1a48_a4dbc3bdb04243eba26c20cdff88c54c~mv2.jpg/v1/fill/w_320,h_320,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/2a1a48_a4dbc3bdb04243eba26c20cdff88c54c~mv2.jpg"
};